export const FACINATIONS_FEATURES = {
  READ_ONLY_MODE: true,

  MINT_ENABLED: false,
  SWAP_ENABLED: false,
  MARKETPLACE_ENABLED: false,
};
