export const CHAIN_CONFIG = {
  chainId: 137, 
  rpcUrl: "https://polygon-rpc.com",
  vaultRegistryAddress: "0xYOUR_DEPLOYED_REGISTRY_ADDRESS"
};

