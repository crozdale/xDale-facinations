import { Link } from "react-router-dom";
import { useTranslation } from "react-i18next";
import "./Header.css";

export default function Header() {
  const { i18n, t } = useTranslation();

  return (
    <header className="site-header">
      <div className="header-inner">
        <Link to="/" className="logo-wrap">
          <img src="/facinations-sigil-gold.png" alt="Facinations" className="site-logo" />
        </Link>

        <nav className="site-nav">
          <Link to="/gallery">{t("nav.gallery")}</Link>
          <Link to="/vaults">{t("nav.vaults")}</Link>
          <Link to="/swap">{t("nav.swap")}</Link>
          <Link to="/legal">{t("nav.legal")}</Link>
        </nav>

        <div className="language-switcher">
          <select
            value={i18n.language}
            onChange={(e) => i18n.changeLanguage(e.target.value)}
          >
            <option value="en">EN</option>
            <option value="fr">FR</option>
          </select>
        </div>
      </div>
    </header>
  );
}
