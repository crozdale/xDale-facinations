export const CONTRACT_ADDRESS = "0xYourContractAddressHere";

export const ABI = [
  "function tokenURI(uint256 tokenId) view returns (string)"
];
