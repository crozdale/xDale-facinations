export const XER_TOKEN = {
  symbol: "XER",
  name: "The Fine Art Coin",
  decimals: 18,
  chainId: 137,
  address: null,
};

