# Façinations™

Façinations™ is a fine-art platform for referencing, vaulting, and preparing
cultural assets for on-chain liquidity.

## Local Development

```bash
npm install
npm run dev
