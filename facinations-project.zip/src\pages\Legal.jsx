export default function Legal() {
  return (
    <main style={{ maxWidth: "900px", margin: "60px auto", padding: "0 24px" }}>
      <h1>Legal</h1>

      <section>
        <h2>Terms of Service</h2>
        <p>
          By accessing or using Facinations, you agree to comply with and be bound
          by these Terms of Service. You are solely responsible for any blockchain
          transactions you initiate.
        </p>
      </section>

      <section>
        <h2>Disclaimer</h2>
        <p>
          Facinations provides decentralized tools without custody or control of
          user assets. Use at your own risk.
        </p>
      </section>

      <section>
        <h2>Privacy Policy</h2>
        <p>
          We do not collect personal data, track users, or store wallet
          information. All interactions occur directly on-chain.
        </p>
      </section>
    </main>
  );
}
