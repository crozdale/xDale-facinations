export const BRAND = {
  FACINATIONS: {
    WORDMARK: "/logos/facinations-gold.png",
    SIGIL: "/logos/facinations-sigil-gold.png",
  },
  XER: {
    SIGIL: "/logos/xer-sigil-gold.svg", // keep for later if/when real
  },
};

