\# Privacy Policy



\_Last updated: {{DATE}}\_



Facinations respects your privacy.



---



\## 1. Data Collection



We do \*\*not\*\* collect:

\- Personal data

\- IP addresses

\- Wallet balances

\- Cookies or trackers



---



\## 2. Wallets



All wallet connections are handled by third-party providers such as MetaMask.

We never access or store private keys.



---



\## 3. Analytics



No tracking or analytics are used.



---



\## 4. Changes



This policy may be updated periodically.



