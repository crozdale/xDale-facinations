export default function Home() {
  return (
    <section
      style={{
        minHeight: "100vh",
        paddingTop: "120px",
        background: "#000",
        color: "#ffd700",
        display: "flex",
        alignItems: "center",
        justifyContent: "center",
        fontSize: "48px",
        fontWeight: "600",
      }}
    >
      FACINATIONS HOME IS RENDERING
    </section>
  );
}
