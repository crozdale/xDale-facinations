export const GALLERY_ITEMS = [
  {
    id: "untitled-study-1",
    title: "Untitled Study I",
    artist: "Artist Name",
    year: 2024,
    medium: "Mixed Media",
    image: null,
    externalUrl: "https://xdalegallery.com/artwork/untitled-study-1",
  },
];
