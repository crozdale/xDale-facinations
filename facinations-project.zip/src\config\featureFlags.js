// Global feature flags for protocol execution

export const FEATURES = {
  VAULT_WRITE_ENABLED: true,
};

