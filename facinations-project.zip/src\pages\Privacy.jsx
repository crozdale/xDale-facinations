import LegalPage from "../components/LegalPage";

export default function Privacy() {
  return <LegalPage file="/legal/privacy.md" />;
}
