export default function Swap() {
  return <h1>Swap</h1>;
}
