// Gallery items will be hydrated from chain / indexer
// Keep empty for now to avoid fake data

export const GALLERY_ITEMS = [];
