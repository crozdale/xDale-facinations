// Asset barrel file (intentionally empty)
// Import static assets here when added
