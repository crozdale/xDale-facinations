// Keep this minimal initially; expand as governance allows.
export const SUPPORTED_PAIRS = [
  {
    chainId: 137,
    fromAsset: "XER",
    toAsset: "FRACTION:VAULT-ALBATRIX-001",
  },
];
