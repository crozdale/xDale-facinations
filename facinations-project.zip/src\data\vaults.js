
export const VAULTS = [
  {
    id: "vault-1",
    address: "0x123...abc",
  },
  {
    id: "vault-2",
    address: "0x456...def",
  },
];
