export default function Vaults() {
  return <h1>Vaults</h1>;
}
