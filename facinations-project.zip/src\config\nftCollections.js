// src/config/nftCollections.js

// Configure the ERC-721 collections shown in the Gallery.
//
// IMPORTANT
// - On-chain wallet token discovery requires ERC721Enumerable
//   (tokenOfOwnerByIndex).
// - Collections without enumeration support will intentionally
//   render an empty state.

expor